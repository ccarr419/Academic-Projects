#!/usr/bin/python
# psTOarff.py, handout for fall 2017 csc458 assignment 1, complete
# your assignment here, refering to lsTOarff.py as a model.
# OUTPUT FROM RUNNING (ps -fu parson && ps -fu root) IS BELOW.
# NOTES:
# From "man ps":
# TIME     accumulated cpu time, user + system. The display format is
#          usually "MMM:SS", but can be shifted to the right if the
#          process used more than 999 minutes of cpu time.
# C        processor utilization. Currently, this is the integer
#          value of the percent usage over the lifetime of the
#          process. (see %cpu). Parson note: Looks like HH:MM:SS
# 1. There is/are header line(s) starting with UID to be discarded.
# 2. In each line we have the following:
#*2a. 1 or more non-whitespace chars making up the UID, could be numeric string.
# 2b. 1 or more whitespace characters as separators.
#*2c. 1 or more digits as a PID.
# 2d. 1 or more whitespace characters as separators.
#*2e. 1 or more digits as a PPID.
# 2f. 1 or more whitespace characters as separators.
#*2g  1 or more digits as % CPU time.
# 2h. 1 or more whitespace characters as separators.
#*2i. 1 or more non-whitespace as start time, current day or day this year.
# 2j. 1 or more whitespace characters as separators.
#*2k. 1 or more non-whitespace as terminal (TTY), translate '?' to 'detached'
# 2l. 1 or more whitespace characters as separators.
#*2m. TIME in HH:MM:SS format, where each of those is 1 or more digits.
# 2n. 1 or more whitespace characters as separators.
#*2o. Everything up to end of line, including mixed-in spaces, is CMD.
# The 8 symbols - UID PID PPID C STIME TTY TIME CMD - are your attributes.
# You can hard code them and your scanner can ignore those lines in the
# input; you must use a regular expression to detect (match) them, but
# they do not contribute any data. Some of the data fields are numeric,
# some are strings (that we might post-process into nominals using Weka),
# there is at least one date (using non-Weka formats). Each data line
# in this input corresponds to one Weka record, so there is no need to
# accumulate data across multiple lines like there is in lsTOarff.py.
# STUDENT NOTE that there is at least one line giving date of the input file:
# DATE OF DATA DUMP: 2017-07-27

# STUDENT 1: Find the "import" statements in lsTOarff.py and add them here.
# understand why you are importing those Python modules.

# DATE OF DATA DUMP: 2017-07-27
# UID        PID  PPID  C STIME TTY          TIME CMD
# parson   20993 20962  0 17:40 ?        00:00:01 sshd: parson@pts/0
# parson   20994 20993  0 17:40 pts/0    00:00:00 -bash
# parson   25271 20994  0 20:10 pts/0    00:00:00 -bash
# parson   25274 25271  0 20:10 pts/0    00:00:00 ps -fu parson
# UID        PID  PPID  C STIME TTY          TIME CMD
# root         1     0  0 May24 ?        00:00:32 /sbin/init
# root         2     0  0 May24 ?        00:00:00 [kthreadd]
# root         3     2  0 May24 ?        00:00:00 [migration/0]
# root         4     2  0 May24 ?        00:00:08 [ksoftirqd/0]
# root         5     2  0 May24 ?        00:00:00 [stopper/0]
# root         6     2  0 May24 ?        00:00:05 [watchdog/0]
# root         7     2  0 May24 ?        00:00:00 [migration/1]
# ETC.

# STUDENT 2: Define Python dictionaries (also known as maps)
# attrNameToProperties and attrPosToName in lsTOarff.py, and build the
# 8-attribute data dictionary for this assignment within them, similar
# to the 20 attributes in lsTOarff.py. There are no "synthesized attributes"
# such as chlds in lsTOarff.py -- they are synthesized from other lines
# of data in the input file -- each line of input to psTOarff.py bears
# all of its own attributes.
# CAVEAT 1: Store the date attribute in seconds. Scan it in the HH:MM:SS
# (hours:minutes:seconds) format like 00:00:08, but convert that to seconds
# for the ARFF attribute. Do NOT assume that the leading fields are 0s.
# CAVEAT 2: STIME is a date (starting time), to be stored as a date in ARFF.
# It comes in two formats, such as "May24" or "17:40". You can assume the
# current year, and for value like 17:40, assume the current day & year.
# Don't try to use time-of-day data, only the date. See lsTOarff.py's
# handling of date for the date attribute.
# Here we are only defining the data dictionary. These CAVEATS apply
# later, during the data-scanning loop.

# STUDENT 3: I am supplying the re (regular expressions) that match the
# output header lines from 'ps', and the DATE OF DATA DUMP line.
# You must supply the re that
# matches the data lines and that captures the data from those lines.
# Yours will have () around the subexpressions that you want to capture.
# NOTES on re meta-characters:
# ^ matches the start of the string; $ matches the end of the string
# + matches one or more of whatever precedes it; * matches zero or more.
# ? matches 0 or 1. The period . matches any one character, so .* matches
# zero or more of any character, and .+ matches one or more of any character.
# I used escape sequences \s+ \S+ \d+ in my solution.
# HERE IS THE SUBEXPRESSION I USED TO MATCH THE STIME date. USE IT:
# (([A-Z][a-z][a-z]\d+)|(\d+:\d+))
# The | is alternation -- it tries to match the left side, or if that fails,
# it tries to match the right. Note that there are 3 ()-delimted groups,
# one of which will always be empty. Those two alternatives are mutually
# exclusive.
__ignorehdr_re__ = re.compile(r'^UID\s+PID\s+PPID\s+C\s+STIME\s+TTY\s+TIME\s+CMD$')
__date_re__ = re.compile(r'^DATE OF DATA DUMP: (\d+)-(\d+)-(\d+)\s*$')
__attributes_re__ = re.compile(r'STUDENT REPLACE THIS STRING WITH YOUR re')

# STUDENT 4: Define your __main__ just like lsTOarff.py, but changing
# the name, usage etc. to psTOarrf where needed. You will have exactly
# the same two command line arguments -- the input file in the format
# seen in /home/KUTZTOWN/parson/DataMine/psTOarff.rawtestdata.txt, and
# the output ARFF file format as in psTOarff.arff.ref. You can open &
# read the input file just as in my lsTOarff.py.

# STUDENT 5: The database list of attrvalues lists, the monthmap, and all
# of the line input code of lsTOarff.py corresponds closely to this program.
# There is no chlds data, there is no curdir across-line data, and you have
# only 3 regular expressions, so your main loop's logic should be simpler.
# Look at psTOarff.arff.ref in /home/KUTZTOWN/parson/DataMine/ to see the
# output from my solution.
# Your output must match it exactly.

if __name__ == "__main__":  # This "if" test is true if called from cmd line.
    usage = "USAGE: python psTOarff.py INFILE OUTARFFFILE.arff"
    # STUDENT CODE GOES BELOW.
